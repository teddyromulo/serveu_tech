<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package storefront
 */

?>

		</div><!-- .col-full -->
	</div><!-- #content -->
	
	<?php do_action( 'storefront_before_footer' ); ?>
	<div>
<?php
//add widget location teddy
//dynamic_sidebar('parallax_homepage');

?>
</div>

<?php if (is_front_page()){ ?>	
<div id="parallax-wrapper" class="clearfix">
	<?php echo do_shortcode('[dd-parallax img="http://www.serveu.tech/wp-content/themes/storefront/images/parallax_bg.jpg" height="600" speed="3" z-index="-100" mobile="mobile-image.jpg" offset="true"]
	<div id="parallax" class="clearfix">
		<div class="clearfix">
			<article>
				<img src="https://www.lexibook.us/templates/jv-venedor/images/lexibook/parallax/home_investor2.png">
				<!--<span>LEXIBOOK GROUP</span>-->
				<span>
					<h3>LEXIBOOK GROUP</h3>
					<p>Update your Lexibook® Apps and enjoy the latest fun!</p>
					<a href="#" class="btn-group">VISIT</a>
				</span>
			</article>		
			<article>
				<img src="https://www.lexibook.us/templates/jv-venedor/images/lexibook/parallax/home_lexibook_club2.png">
				<span>
					<h3>VIDEOS</h3>
					<p>Watch the demo video here on how to use our products</p>
					<a href="#" class="btn-videos">VISIT</a>
				</span>
			</article>		
			<article>
				<img src="https://www.lexibook.us/templates/jv-venedor/images/lexibook/parallax/home_lexibook_assistance2.png">
				<span>
					<h3>SUPPORT</h3>
					<p>Need help to use our products? Let\'s consult our online assistance.</p>
					<a href="#" class="btn-support">VISIT</a>
				</span>
			</article>
		</div>
	</div>	
	[/dd-parallax]'); ?>
	</div>
<?php }	?>	


	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="col-full">

			<?php
			/**
			 * Functions hooked in to storefront_footer action
			 *
			 * @hooked storefront_footer_widgets - 10
			 * @hooked storefront_credit         - 20
			 */
			do_action( 'storefront_footer' ); ?>

		</div><!-- .col-full -->
		<?php
		//add widget location teddy
		dynamic_sidebar('footer_bottom');
		?>

	</footer><!-- #colophon -->

<?php do_action( 'storefront_after_footer' ); ?>
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
